#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/input.h>

int main()
{
	printf("Starting key watcher\n");

	size_t file;
	const char *str = "/dev/input/event8";

	printf("File Path: %s\n", str);

	if((file = open(str, O_RDWR)) < 0)
	{
		printf("ERROR:File can not open\n");
		exit(0);
	}

	struct input_event event[64];

        size_t reader;
        reader = read(file, &event, sizeof(struct input_event) * 64);

        printf("DO NOT COME HERE...\n");

	close(file);
	return 0;
}

