#include <linux/init.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/slab.h>
#include <linux/of.h>
#include <linux/pm_runtime.h>
#include <uapi/linux/serial_reg.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/of_irq.h>
#include <linux/interrupt.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/mutex.h>

#include <asm/processor.h>
#include <asm/irq.h>
#include <linux/delay.h>
 
#define SERIAL_RESET_COUNTER 0
#define SERIAL_GET_COUNTER 1


#define SERIAL_BUFSIZE 16

struct feserial_dev {
        int serial_buf_wr;
        wait_queue_head_t serial_wait;
        spinlock_t lock;
        struct miscdevice miscdev;
        void __iomem *regs;
        unsigned long counter;
        int irq;
        char serial_buf[SERIAL_BUFSIZE];
        int serial_buf_rd;
};


static unsigned int REG_READ(struct feserial_dev *dev, int off) {
        return readl(dev->regs + 4*off);
}

static void REG_WRITE(struct feserial_dev *dev, int c, int off) {
        writel(c, dev->regs + 4*off);
}

static void WRITE_CHAR(struct feserial_dev* dev, char c)
{
       while((REG_READ(dev, UART_TX) & UART_LSR_THRE))
        cpu_relax();

        REG_WRITE(dev, c, UART_TX);
}



static ssize_t feserial_write(struct file *file, const char __user *s, size_t size, loff_t *flag)
{
        struct feserial_dev *dev = container_of(file->private_data, struct feserial_dev, miscdev);
        size_t i;
        char c;
        const char __user *user_s=s;
       
       
        for( i=0 ; i<size ; i++ )
        {
                get_user(c,user_s++);
                spin_lock(&dev->lock);
                WRITE_CHAR( dev, &c);
                if( strncmp(&c,"\n",1) == 0)
                        WRITE_CHAR( dev, "\r");
                spin_unlock(&dev->lock);
        }
        return i;
}
 
static ssize_t feserial_read(struct file *file, char __user *s, size_t size, loff_t *flag)
{
        struct feserial_dev *dev = container_of(file->private_data, struct feserial_dev, miscdev);
 
        wait_event_interruptible(dev->serial_wait,
                                 dev->serial_buf_wr != dev->serial_buf_rd);
 
        if( dev->serial_buf_wr != dev->serial_buf_rd)
        {
                put_user( dev->serial_buf[dev->serial_buf_rd++], s);
                if( dev->serial_buf_rd == SERIAL_BUFSIZE )
                        dev->serial_buf_rd = 0;
        }
       
        return 1;
}

static long feserial_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
        void __user *argp = (void __user *)arg;
        struct feserial_dev *dev = container_of(file->private_data, struct feserial_dev, miscdev);
       
        switch (cmd) {
        case SERIAL_RESET_COUNTER:
                dev->counter = 0;
                break;
        case SERIAL_GET_COUNTER:
                if( copy_to_user(argp,&dev->counter,sizeof(dev->counter)) )
                        return -EFAULT;
                break;
        default:
                return -ENOTTY;
        }
 
        return 0;
}

static const struct file_operations feserial_ops = {
        .owner          = THIS_MODULE,
//      .open           = feserial_open,
        .write          = feserial_write,
        .read           = feserial_read,
//      .close          = feserial_close
        .unlocked_ioctl = feserial_ioctl
};


// #define VAL(port, off) (port + 4 * off)

// #define REG_WRITE(port, v, off)  (writel(v, VAL(port->regs, off) ))

// #define REG_READ(port, off) (readl( VAL(port->regs, off) ))




static int feserial_probe(struct platform_device *pdev)
{
        struct feserial_dev *dev;
        struct resource *res;
        unsigned int uartclk, baud_divisor, i;


        pr_info("Called feserial_probe\n");

        dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
        if (dev == NULL) {
                dev_err(&pdev->dev, "Cannot allocate dev\n");
                return -ENOMEM;
        }

        res = platform_get_resource(pdev, IORESOURCE_MEM, 0);

        if(!res)
                return -EBUSY;

        dev->regs = devm_ioremap_resource(&pdev->dev, res);
        if (!dev->regs) 
        {
                return PTR_ERR(dev->regs);
        }

        pm_runtime_enable(&pdev->dev);
        pm_runtime_get_sync(&pdev->dev);
        
        /* Configure the baud rate to 115200 */

        of_property_read_u32(pdev->dev.of_node, "clock-frequency", &uartclk);
        pr_info("clock-frequency, %d\n", uartclk);
        baud_divisor = uartclk / 16 / 115200;
        REG_WRITE(dev, 0x07, UART_OMAP_MDR1);
        REG_WRITE(dev, 0x00, UART_LCR);
        REG_WRITE(dev, UART_LCR_DLAB, UART_LCR);
        REG_WRITE(dev, baud_divisor & 0xff, UART_DLL);
        REG_WRITE(dev, (baud_divisor >> 8) & 0xff, UART_DLM);
        REG_WRITE(dev, UART_LCR_WLEN8, UART_LCR);

        /* Soft reset */
        REG_WRITE(dev, UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT, UART_FCR);
        REG_WRITE(dev, 0x00, UART_OMAP_MDR1);

        /* 1. Wait until the UART_LSR_THRE bit gets set in the UART_LSR register. You can busy-wait
        for this condition to happen. In the busy-wait loop, you can call the cpu_relax() kernel
        function to ensure the compiler won’t optimise away this loop. */
        msleep(10);

        for(i = 0; i < 10 ; i++)
        {
                while (!(REG_READ(dev, UART_LSR) & UART_LSR_THRE) ) {
                       cpu_relax();
                }
                REG_WRITE( dev, 'A', UART_TX);
        }
                
        pr_info("Write called\n");
	return 0;
}

static int feserial_remove(struct platform_device *pdev)
{
	pr_info("Called feserial_remove\n");

        pm_runtime_disable(&pdev->dev);

        return 0;
}



#ifdef CONFIG_OF
static const struct of_device_id feserial_ids[] = {
        { .compatible = "free-electrons,serial" },
        { /* Sentinel */ }
};

MODULE_DEVICE_TABLE(of, feserial_ids);
#endif

static struct platform_driver feserial_driver = {
        .driver = {
                .name = "feserial",
                .owner = THIS_MODULE,
                .of_match_table = feserial_ids
        },
        .probe = feserial_probe,
        .remove = feserial_remove,    
};

module_platform_driver(feserial_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Andreas d'Erasmo");
MODULE_DESCRIPTION("FMC serial driver");

