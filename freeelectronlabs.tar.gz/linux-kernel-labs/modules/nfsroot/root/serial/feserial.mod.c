#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x7d84f313, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x61dd563a, __VMLINUX_SYMBOL_STR(platform_driver_unregister) },
	{ 0xd75709a6, __VMLINUX_SYMBOL_STR(__platform_driver_register) },
	{ 0xf9a482f9, __VMLINUX_SYMBOL_STR(msleep) },
	{ 0x822137e2, __VMLINUX_SYMBOL_STR(arm_heavy_mb) },
	{ 0x6e5dba7a, __VMLINUX_SYMBOL_STR(of_property_read_u32_array) },
	{ 0xf73d1c6d, __VMLINUX_SYMBOL_STR(__pm_runtime_resume) },
	{ 0xb63a289c, __VMLINUX_SYMBOL_STR(pm_runtime_enable) },
	{ 0xbf1c6693, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x2c85e445, __VMLINUX_SYMBOL_STR(devm_ioremap_resource) },
	{ 0x5448fe57, __VMLINUX_SYMBOL_STR(platform_get_resource) },
	{ 0x76e44103, __VMLINUX_SYMBOL_STR(devm_kmalloc) },
	{ 0xe707d823, __VMLINUX_SYMBOL_STR(__aeabi_uidiv) },
	{ 0xefd6cf06, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr0) },
	{ 0x84382de5, __VMLINUX_SYMBOL_STR(__pm_runtime_disable) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("of:N*T*Cfree-electrons,serial");

MODULE_INFO(srcversion, "E9986D455496BD2A7674921");
