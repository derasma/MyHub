

#include <linux/init.h>
#include <linux/module.h>
#include <linux/i2c.h>
#include <linux/input-polldev.h>
#include <linux/delay.h>
#include <linux/input.h>
#include <linux/slab.h>

struct nunchuk_dev {
	struct i2c_client *i2c_client;
	struct input_polled_dev *polled_input;
};

static int nunchuk_read_registers(struct i2c_client *client, u8 *recv)
{
	u8 buf[1];
	int ret;

	/* Ask the device to get ready for a read */

	mdelay(10);

	buf[0] = 0x00;
	ret = i2c_master_send(client, buf, 1);
	if (ret != 1) {
		dev_err(&client->dev, "i2c send failed (%d)\n", ret);
		return ret < 0 ? ret : -EIO;
	}

	mdelay(10);

	/* Now read registers */

	ret = i2c_master_recv(client, recv, 6);
	if (ret != 6) {
		dev_err(&client->dev, "i2c recv failed (%d)\n", ret);
		return ret < 0 ? ret : -EIO;
	}

	return 0;
}


void nunchuck_poll(struct input_polled_dev *polled_input)
{
	u8 recv[6];
	int zpressed, cpressed;
	struct nunchuk_dev *nunchuk = polled_input->private;
	struct i2c_client *client = nunchuk->i2c_client;

	if (!nunchuk || !client)
		return;

	if (nunchuk_read_registers(client, recv) < 0)
		return;

/*
	Byte 0x00 : X-axis data of the joystick
	Byte 0x01 : Y-axis data of the joystick
	Byte 0x02 : X-axis data of the accellerometer sensor
	Byte 0x03 : Y-axis data of the accellerometer sensor
	Byte 0x04 : Z-axis data of the accellerometer sensor
	Byte 0x05 :
	C-button
	Z-button
	0x05
	bit 0 as Z button status - 0 = pressed and 1 = release
	bit 1 as C button status - 0 = pressed and 1 = release
	bit 2 and 3 as 2 lower bit of X-axis data of the accellerometer sensor
	bit 4 and 5 as 2 lower bit of Y-axis data of the accellerometer sensor
	bit 6 and 7 as 2 lower bit of Z-axis data of the accellerometer sensor

	for(i = 0; i < 6 ; i++)
	{
		pr_alert(" buff[%d]: %X,", i, rc_buff[i]);
	}
	pr_alert("\n");

*/

	zpressed = (recv[5] & BIT(0)) ? 0 : 1;

	if (zpressed)
		dev_info(&client->dev, "Z button pressed\n");

	cpressed = (recv[5] & BIT(1)) ? 0 : 1;

	if (cpressed)
		dev_info(&client->dev, "C button pressed\n");

	/* Send events to the INPUT subsystem */
	input_event(polled_input->input,
		    EV_KEY, BTN_Z, zpressed);

	input_event(polled_input->input,
		    EV_KEY, BTN_C, cpressed);

	input_sync(polled_input->input);
}

static int nunchuk_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	struct nunchuk_dev *nunchuk;
	struct input_polled_dev *polled_input;
	struct input_dev *input;
	int byte, zpressed, cpressed;
	char rc_buff[6];
	char buffer[] = {0xf0, 0x55, 0xfb, 0x00, 0x01};

	pr_alert("Hello nunchuk probe.\n");


	nunchuk = devm_kzalloc(&client->dev, sizeof(struct nunchuk_dev), GFP_KERNEL);
	if (!nunchuk) 
	    return -ENOMEM;
	
	polled_input = input_allocate_polled_device();
	if(!polled_input)
	  	return -ENOMEM;

	nunchuk->i2c_client = client;
	nunchuk->polled_input = polled_input;

	i2c_set_clientdata(client, nunchuk);

	byte = i2c_master_send(nunchuk->i2c_client, &buffer[0], 2);
	if(byte == 2)
		pr_alert("The buffer was sent successfully");
	else
		pr_alert("failed to send buffer ");

	msleep(10);

	byte = i2c_master_send(nunchuk->i2c_client, &buffer[2], 2);
	if(byte == 2)
		pr_alert("The buffer was sent successfully\n");
	else
		pr_alert("failed to send buffer\n");	
	
	input = polled_input->input;
	input->name = "Wii Nunchuk";
	input->id.bustype = BUS_I2C;

	set_bit(EV_KEY, input->evbit);
	set_bit(BTN_C, input->keybit);
	set_bit(BTN_Z, input->keybit);
	
	byte = input_register_polled_device(polled_input);
	if(byte)
	{
		input_free_polled_device(polled_input);
		return -1;
	}

	msleep(10);
	byte =  i2c_master_send(nunchuk->i2c_client, &buffer[3], 1);
	if( byte == 1 )
	{
		pr_alert("The buffer was sent successfully\n");
		msleep(10);
		byte = i2c_master_recv(nunchuk->i2c_client, rc_buff, 6);
		pr_alert("receic status: %d\n", byte );
	
		zpressed = (rc_buff[5] & BIT(0)) ? 0 : 1;

		if(zpressed)
			dev_info(&client->dev, "Z button pressed\n");

		cpressed = (rc_buff[5] & BIT(1)) ? 0 : 1;

		if(cpressed)
			dev_info(&client->dev, "C button pressed\n");
	}
	else
		pr_alert("failed to receive request\n");

	return 0;
}

static int nunchuk_remove(struct i2c_client *client)
{
	struct nunchuk_dev *nunchuk;
	
	pr_alert("Hello nunchuk remove.\n");

	nunchuk = i2c_get_clientdata(client);
	input_unregister_polled_device(nunchuk->polled_input);
	input_free_polled_device(nunchuk->polled_input);

	return 0;
}

static const struct i2c_device_id nunchuk_id[] = {
	{ "nunchuk", 0 },
	{ }
};

MODULE_DEVICE_TABLE(i2c, nunchuk_id);
#ifdef CONFIG_OF
	static const struct of_device_id nunchuk_dt_ids[] = {
		{ .compatible = "nintendo,nunchuk", },
		{ }
	};
	MODULE_DEVICE_TABLE(of, nunchuk_dt_ids);
#endif

static struct i2c_driver nunchuk_driver = {
	.probe = nunchuk_probe,
	.remove = nunchuk_remove,
	.id_table = nunchuk_id,
	.driver = {
	.name = "nunchuk",
	.owner = THIS_MODULE,
	.of_match_table = of_match_ptr(nunchuk_dt_ids),
	},
};
module_i2c_driver(nunchuk_driver);

MODULE_LICENSE("GPL");



