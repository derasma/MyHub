#!/bin/bash
#
#	insmod nunchuk.ko
#	rmmod nunchuk.ko
#

#make dtbs
if [ "$(echo $1 | grep "d")" != "" ]; then
	cp ~/freeelectronslab/linux-kernel-labs/modules/nfsroot/root/nunchuk/am335x-customboneblack.dts ~/linux-kernel-labs/src/linux/linux/arch/arm/boot/dts/am335x-customboneblack.dts
	pushd ~/linux-kernel-labs/src/linux/linux/
	make dtbs
	sudo cp ./arch/arm/boot/dts/am335x-customboneblack.dtb /var/lib/tftpboot/
	popd
fi

#make kernel 
if [ "$(echo $1 | grep "k")" != "" ]; then
	pushd ~/linux-kernel-labs/src/linux/linux/
	make
	sudo cp ./arch/arm/boot/zImage /var/lib/tftpboot
	popd
fi

pushd ~/freeelectronslab/linux-kernel-labs/modules/nfsroot/root/nunchuk/
make
popd
